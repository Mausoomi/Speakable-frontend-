import React from 'react'

const AdminSettings = () => {
  return (
    <div>AdminSettings</div>
  )
}

export default AdminSettings