import React from 'react'

const TeacherFeedback = () => {
  return (
    <div>TeacherFeedback</div>
  )
}

export default TeacherFeedback